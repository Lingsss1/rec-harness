# KuaiRec focused incumbent baseline

- Experiment: `auc41-q3zero-fullval-kuai-s27-incumbent`
- Base experiment: `QFormerCross11_KuaiRec_Big_Watch_Action`
- Validation AUC: `0.8877503059607915`
- Seed: `20262027`
- Checkpoint (not bundled): `autoresearch/checkpoints/KuaiRec_Big_Watch_Action/auc41-q3zero-fullval-kuai-s27.model`
- Training query scales: `[1, 1, 1, 1, 1, 1, 1, 1]`
- Deployed fixed query scales: `[1, 1, 1, 0, 1, 1, 1, 1]`
- Gradient clipping: `max_gradient_norm=1`
- Iterative metric: validation AUC only; test remains untouched.

The bundle contains `QFormerCross8.py`, `QFormerCross10.py`, and
`QFormerCross11.py` because QFormerCross11 imports the first two. The complete
project still provides the `unirank` framework imported by those modules.
