# =========================================================================
# Copyright (C) 2026. UniRank Authors. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# =========================================================================

from functools import partial

from torch import nn

from .QFormerCross8 import QFormerCross8
from .QFormerCross10 import (
    NonRecursiveCrossValueLayer,
    NonRecursiveCrossValueStage,
)


class OriginalXQFormerStage(nn.Module):
    """Standard QFormer layers that always cross against the original X.

    Queries evolve from layer to layer, but ``source_tokens`` is never
    overwritten. Consequently every CrossValue attention receives the same
    original stage input as both its key and value source::

        Q_l'    = SelfAttention(Q_l)
        Q_l''   = CrossValue(Q_l', K=X, V=X)
        Q_(l+1) = FFN(Q_l'')
    """

    def __init__(self, token_dim, num_heads, num_layers, ffn_dim,
                 dropout=0.0, qk_norm=False,
                 final_ffn_ratio=None, final_ffn_residual_scale=1.0,
                 final_ffn_learned_scale_mode="none",
                 final_ffn_learned_scale_bound=0.0, num_queries=None,
                 **_compat_kwargs):
        super().__init__()
        if final_ffn_ratio is not None and final_ffn_ratio <= 0:
            raise ValueError("final_ffn_ratio must be positive")
        if not 0 <= final_ffn_residual_scale <= 1:
            raise ValueError("final_ffn_residual_scale must be in [0, 1]")
        scale_shapes = {
            "none": None,
            "scalar": (1, 1, 1),
            "channel": (1, 1, token_dim),
            "query": (1, num_queries, 1) if num_queries else None,
            "query_channel": (1, num_queries, token_dim) if num_queries else None,
        }
        if final_ffn_learned_scale_mode not in scale_shapes:
            raise ValueError("unsupported final FFN learned scale mode")
        if final_ffn_learned_scale_mode.startswith("query") and num_queries is None:
            raise ValueError("query-local final FFN scales require num_queries")
        if not 0 <= final_ffn_learned_scale_bound <= 0.5:
            raise ValueError("final FFN learned scale bound must be in [0, 0.5]")
        if (final_ffn_learned_scale_mode == "none") != (
                final_ffn_learned_scale_bound == 0):
            raise ValueError("learned final FFN scaling requires mode and positive bound")
        layers = []
        for index in range(num_layers):
            is_final = index == num_layers - 1
            layer_ffn_dim = (
                int(token_dim * final_ffn_ratio)
                if is_final and final_ffn_ratio is not None else ffn_dim
            )
            layers.append(NonRecursiveCrossValueLayer(
                token_dim=token_dim,
                num_heads=num_heads,
                ffn_dim=layer_ffn_dim,
                dropout=dropout,
                qk_norm=qk_norm,
                ffn_residual_scale=(final_ffn_residual_scale if is_final else 1.0),
                ffn_learned_scale_shape=(
                    scale_shapes[final_ffn_learned_scale_mode] if is_final else None
                ),
                ffn_learned_scale_bound=(
                    final_ffn_learned_scale_bound if is_final else 0.0
                ),
            ))
        self.layers = nn.ModuleList(layers)
        self.final_norm = nn.LayerNorm(token_dim)

    def forward(self, queries, source_tokens, source_mask=None):
        # Keep this reference fixed: only queries are updated between layers.
        original_x = source_tokens
        for layer in self.layers:
            queries = layer(queries, original_x, source_mask)
        return self.final_norm(queries)


class QFormerCross11(QFormerCross8):
    """Original QFormer order with immutable CrossValue source streams.

    Both stages restore the per-layer Self-Attention -> Cross-Attention -> FFN
    structure. Every cross-attention layer uses the unmodified stage input X
    as V (and K); only the latent queries are propagated across layers.
    """

    def __init__(self, feature_map, model_id="QFormerCross11", **kwargs):
        final_options = {
            "final_ffn_ratio": kwargs.pop("unified_final_ffn_ratio", None),
            "final_ffn_residual_scale": kwargs.pop(
                "unified_final_ffn_residual_scale", 1.0
            ),
            "final_ffn_learned_scale_mode": kwargs.pop(
                "unified_final_ffn_learned_scale_mode", "none"
            ),
            "final_ffn_learned_scale_bound": kwargs.pop(
                "unified_final_ffn_learned_scale_bound", 0.0
            ),
        }
        super().__init__(
            feature_map,
            model_id=model_id,
            _ns_qformer_cls=NonRecursiveCrossValueStage,
            _unified_qformer_cls=partial(OriginalXQFormerStage, **final_options),
            **kwargs,
        )
